package com.example.timebarterbeta0.model

interface  AccountContract {
    interface  ViewRegister {

        fun showLoading()
        fun registerSuccess()
        fun registerFailed()
        fun hideLoading()

        fun invalidName()
        fun invalidEmail()
        fun invalidPassword()
    }

    interface ViewLogin {

        fun showLoading()
        fun loginSuccess()
        fun loginFailed()
        fun hideLoading()

        fun invalidEmail()
        fun invalidPassword()

    }
    interface Presenter {

        fun createAccount(nama : String, email : String, password : String)
        fun loginAccount (email: String, password: String)
        fun validateInputRegister(account: Account): Boolean
        fun validateInputlogin(account: Account): Boolean
    }
}