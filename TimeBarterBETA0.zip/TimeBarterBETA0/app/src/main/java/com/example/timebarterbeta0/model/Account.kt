package com.example.timebarterbeta0.model

data class Account (
    val nama : String,
    val email: String,
    val password : String
)