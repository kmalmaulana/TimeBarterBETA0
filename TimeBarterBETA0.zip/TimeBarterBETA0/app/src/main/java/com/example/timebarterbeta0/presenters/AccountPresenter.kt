package com.example.timebarterbeta0.presenters

import android.util.Patterns
import com.example.timebarterbeta0.model.Account
import com.example.timebarterbeta0.model.AccountContract
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class AccountPresenter : AccountContract.Presenter {

    private lateinit var mViewRegister: AccountContract.ViewRegister
    private lateinit var mViewLogin : AccountContract.ViewLogin

    constructor(mViewRegister: AccountContract.ViewRegister) {
        this.mViewRegister = mViewRegister
    }

    constructor(mViewLogin: AccountContract.ViewLogin) {
        this.mViewLogin = mViewLogin
    }

    override fun createAccount(nama: String, email: String, password: String) {

        val auth = FirebaseAuth.getInstance()
        val database = FirebaseDatabase.getInstance().reference.child("Users")

        val account = Account(nama, email, password)

        if (validateInputRegister(account)) {

            mViewRegister.showLoading()

            auth.createUserWithEmailAndPassword(account.email,account.password)
                .addOnCompleteListener {
                    if (it.isSuccessful) {

                        val uId = auth.currentUser!!.uid
                        val uIdDB : DatabaseReference = database.child(uId)

                        uIdDB.child("Name").setValue(account.nama)
                        uIdDB.child("Email").setValue(account.email)

                        mViewRegister.registerSuccess()
                        mViewRegister.hideLoading()

                    } else {

                        mViewRegister.registerFailed()
                        mViewRegister.hideLoading()

                    }
                }
        }

    }

    override fun validateInputRegister(account: Account): Boolean {

        var valid = false

        if (account.nama.length > 3) {
            valid = true

            if(Patterns.EMAIL_ADDRESS.matcher(account.email).matches()) {
                valid = true

                if(account.password.length > 6) {
                    valid = true
                } else {
                    valid = false
                    mViewRegister.invalidPassword()
                }

            } else {
                valid = false
                mViewRegister.invalidEmail()
            }

        } else {
            valid = false
            mViewRegister.invalidName()
        }

        return  valid
    }

    override fun loginAccount(email: String, password: String) {

        val auth = FirebaseAuth.getInstance()

        val account = Account("", email, password )

        if (validateInputlogin(account)) {

            auth.signInWithEmailAndPassword(account.email, account.password)
                .addOnCompleteListener {

                    if (it.isSuccessful) {

                        mViewLogin.loginSuccess()

                    } else {

                        mViewLogin.loginFailed()

                    }
                }
        }
    }

    override fun validateInputlogin(account: Account): Boolean {
        var valid = false

        if (Patterns.EMAIL_ADDRESS.matcher(account.email).matches()) {
            valid = true

            if (!account.password.isEmpty()) {
                valid = true

            } else {
                valid = false

                mViewLogin.invalidPassword()
            }

        } else {

            valid = false
            mViewLogin.invalidEmail()
        }

        return valid

    }
}