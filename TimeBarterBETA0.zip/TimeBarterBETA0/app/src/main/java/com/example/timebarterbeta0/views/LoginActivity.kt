package com.example.timebarterbeta0.views

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.Toast
import com.example.timebarterbeta0.R
import com.example.timebarterbeta0.extentions.gone
import com.example.timebarterbeta0.extentions.visible
import com.example.timebarterbeta0.model.AccountContract
import com.example.timebarterbeta0.presenters.AccountPresenter
import kotlinx.android.synthetic.main.login_activity.*
import kotlinx.android.synthetic.main.register_activity.*

class LoginActivity : AppCompatActivity (), AccountContract.ViewLogin {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_activity)

        val presenter = AccountPresenter(this)

        button_login.setOnClickListener {
            presenter.loginAccount(field_login_email.text.toString(), field_login_password.text.toString())

        }
    }

    override fun showLoading() {
        progressBar_login.visible()
    }

    override fun loginSuccess() {
        Toast.makeText(this@LoginActivity, "Selamat Datang!", Toast.LENGTH_LONG).show()

        startActivity(Intent(this@LoginActivity, MainActivity::class.java))
    }

    override fun loginFailed() {
        Toast.makeText(this@LoginActivity, "Email dan Password salah!", Toast.LENGTH_LONG).show()
    }

    override fun hideLoading() {
        progressBar_login.gone()
    }

    override fun invalidEmail() {
        Toast.makeText(this@LoginActivity, "Tolong masukkan Email dengan benar!", Toast.LENGTH_SHORT).show()
    }

    override fun invalidPassword() {
        Toast.makeText(this@LoginActivity, "Password tidak boleh kosong", Toast.LENGTH_SHORT).show()
    }
}